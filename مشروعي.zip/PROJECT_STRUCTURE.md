# هيكل المشروع - REX

## 📁 البنية الأساسية

```
digital-services/
├── client/                          # تطبيق React الأمامي
│   ├── src/
│   │   ├── pages/                   # صفحات التطبيق
│   │   │   ├── Home.tsx             # الصفحة الرئيسية
│   │   │   ├── AdminDashboard.tsx   # لوحة التحكم
│   │   │   ├── ModelsPage.tsx       # صفحة الموديلات
│   │   │   ├── VoiceArtistsPage.tsx # صفحة المعلقين
│   │   │   ├── ContentCreatorsPage.tsx # صفحة صناع المحتوى
│   │   │   ├── VideoProductionPage.tsx # صفحة الفيديو
│   │   │   ├── ContentWritingPage.tsx  # صفحة الكتابة
│   │   │   └── NotFound.tsx         # صفحة 404
│   │   │
│   │   ├── components/              # مكونات React المشتركة
│   │   │   ├── ui/                  # مكونات shadcn/ui
│   │   │   ├── Header.tsx           # رأس الصفحة
│   │   │   ├── Footer.tsx           # تذييل الصفحة
│   │   │   ├── ContactForm.tsx      # نموذج التواصل
│   │   │   ├── DashboardLayout.tsx  # تخطيط لوحة التحكم
│   │   │   ├── ErrorBoundary.tsx    # معالج الأخطاء
│   │   │   ├── Map.tsx              # مكون الخريطة
│   │   │   ├── ImageUpload.tsx      # رفع الصور
│   │   │   ├── AudioUpload.tsx      # رفع الصوت
│   │   │   ├── AIChatBox.tsx        # صندوق الدردشة
│   │   │   └── ManusDialog.tsx      # نافذة Manus
│   │   │
│   │   ├── hooks/                   # React Hooks مخصصة
│   │   │   ├── useMobile.tsx        # الكشف عن الجوال
│   │   │   ├── useComposition.ts    # إدارة التركيب
│   │   │   └── usePersistFn.ts      # دالة مستمرة
│   │   │
│   │   ├── _core/hooks/
│   │   │   └── useAuth.ts           # إدارة المصادقة
│   │   │
│   │   ├── lib/                     # مساعدات وأدوات
│   │   │   ├── trpc.ts             # عميل tRPC
│   │   │   ├── utils.ts            # دوال مساعدة عامة
│   │   │   └── vimeo-utils.ts      # أدوات Vimeo
│   │   │
│   │   ├── contexts/                # React Contexts
│   │   │   └── ThemeContext.tsx     # سياق المظهر
│   │   │
│   │   ├── App.tsx                  # التطبيق الرئيسي
│   │   ├── main.tsx                 # نقطة الدخول
│   │   ├── index.css                # الأنماط العامة
│   │   └── const.ts                 # الثوابت
│   │
│   ├── public/                      # الملفات الثابتة
│   │   ├── banner-1.jpg
│   │   ├── banner-2.jpg
│   │   ├── hero-banner.png
│   │   ├── hero-bg.jpg
│   │   └── ...
│   │
│   └── index.html                   # HTML الرئيسي
│
├── server/                          # خادم Node.js
│   ├── _core/                       # المكتبات الأساسية
│   │   ├── index.ts                 # نقطة دخول الخادم
│   │   ├── context.ts               # سياق tRPC
│   │   ├── trpc.ts                  # إعدادات tRPC
│   │   ├── env.ts                   # متغيرات البيئة
│   │   ├── oauth.ts                 # المصادقة OAuth
│   │   ├── cookies.ts               # إدارة الكوكيز
│   │   ├── storage.ts               # تخزين S3
│   │   ├── imageGeneration.ts       # توليد الصور
│   │   ├── llm.ts                   # نماذج اللغة
│   │   ├── notification.ts          # الإشعارات
│   │   ├── map.ts                   # خدمات الخريطة
│   │   ├── voiceTranscription.ts    # تحويل الصوت
│   │   ├── dataApi.ts               # واجهة البيانات
│   │   ├── sdk.ts                   # SDK مخصص
│   │   ├── vite.ts                  # إعدادات Vite
│   │   ├── systemRouter.ts          # موجهات النظام
│   │   └── types/                   # تعريفات الأنواع
│   │
│   ├── routers.ts                   # تعريف API endpoints
│   ├── index.ts                     # إعدادات الخادم
│   ├── db.ts                        # اتصال قاعدة البيانات
│   ├── db-models.ts                 # نماذج قاعدة البيانات
│   ├── storage.ts                   # خدمات التخزين
│   └── upload.ts                    # معالج الرفع
│
├── shared/                          # الملفات المشتركة
│   ├── const.ts                     # الثوابت المشتركة
│   ├── types.ts                     # الأنواع المشتركة
│   ├── services.ts                  # الخدمات المشتركة
│   └── _core/errors.ts              # معالجة الأخطاء
│
├── drizzle/                         # إدارة قاعدة البيانات
│   ├── schema.ts                    # تعريف الجداول
│   ├── relations.ts                 # العلاقات بين الجداول
│   └── migrations/                  # ملفات الهجرات
│
├── dist/                            # ملفات البناء (مُنتجة)
├── node_modules/                    # المتطلبات
├── patches/                         # تصحيحات المتطلبات
│
├── package.json                     # المتطلبات والـ scripts
├── pnpm-lock.yaml                   # قفل الإصدارات
├── tsconfig.json                    # إعدادات TypeScript
├── tsconfig.node.json               # إعدادات TypeScript للخادم
├── vite.config.ts                   # إعدادات Vite
├── vitest.config.ts                 # إعدادات Vitest
├── drizzle.config.ts                # إعدادات Drizzle
├── .prettierrc                      # إعدادات Prettier
├── .prettierignore                  # ملفات مستثناة من Prettier
├── .gitignore                       # ملفات مستثناة من Git
│
├── README.md                        # دليل المشروع
├── ARCHITECTURE.md                  # معمارية المشروع
├── DEPLOYMENT.md                    # دليل النشر
└── PROJECT_STRUCTURE.md             # هذا الملف
```

## 🎯 شرح الأقسام الرئيسية

### Frontend (`client/src/`)
- **pages**: كل صفحة في التطبيق
- **components**: مكونات قابلة لإعادة الاستخدام
- **hooks**: منطق مشترك
- **lib**: أدوات ومساعدات
- **contexts**: حالة عامة للتطبيق

### Backend (`server/`)
- **_core**: وظائف أساسية (OAuth, Storage, LLM, إلخ)
- **routers.ts**: تعريف جميع API endpoints
- **db.ts**: اتصال قاعدة البيانات

### Database (`drizzle/`)
- **schema.ts**: تعريف جميع الجداول
- **migrations/**: سجل التغييرات

## 📊 الملفات المهمة

| الملف | الوصف |
|------|-------|
| `App.tsx` | التطبيق الرئيسي والموجهات |
| `routers.ts` | جميع API endpoints |
| `schema.ts` | تعريف قاعدة البيانات |
| `index.css` | الأنماط العامة والألوان |
| `package.json` | المتطلبات والأوامر |

## 🔄 تدفق البيانات

```
User Input (Frontend)
    ↓
React Component
    ↓
tRPC Mutation/Query
    ↓
Server Router
    ↓
Database (Drizzle)
    ↓
Response
    ↓
UI Update
```

## 📝 ملاحظات مهمة

1. **المسارات**: استخدم `@/` للـ client و `@shared/` للملفات المشتركة
2. **الصور**: ضع الصور في `client/public/` واستخدمها بـ `/image-name.jpg`
3. **الأنماط**: عدّل الألوان في `client/src/index.css`
4. **API**: أضف endpoints جديدة في `server/routers.ts`
5. **قاعدة البيانات**: عدّل الجداول في `drizzle/schema.ts` ثم شغّل `pnpm db:push`

---

**آخر تحديث**: ديسمبر 2025
